//
//  ResultTableViewCell.swift
//  SolievGame
//
//  Created by user on 15.10.2021.
//

import UIKit

class ResultTableViewCell: UITableViewCell {

    @IBOutlet weak var namePlayer: UILabel!
    @IBOutlet weak var gameResult: UILabel!
    @IBOutlet weak var timeResult: UILabel!

}
